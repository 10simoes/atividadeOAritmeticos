#include<stdio.h>


main(){

    int num1;
    int num2;
    int resultadoSoma;
    int resultadoSub;
    int resultadoMult;
    int resultadoDiv;

    printf("\nDigite o primeiro numero: ");
    scanf("%d",&num1);

    printf("\nDigite o segundo numero: ");
    scanf("%d",&num2);

    resultadoDiv = num1/num2;
    resultadoMult = num1*num2;
    resultadoSoma = num1 + num2;
    resultadoSub = num1 - num2;

    printf("\nO resultado da soma é: %d",resultadoSoma);
    printf("\nO resultado da divisao é: %d",resultadoDiv);
    printf("\nO resultado da subtracao é: %d",resultadoSub);
    printf("\nO resultado da multiplicacao é: %d ",resultadoMult);

    

}