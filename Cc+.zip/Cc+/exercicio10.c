#include<stdio.h>

main(){

    float numCarros, totalVendas, salarioFixo, valorPorCarro, salarioFinal, comissaoFixa = 0.05;

    printf("\n Digite a quantidade de carros vendidos: ");
    scanf("%f",&numCarros);

    printf("\n Digite o valor total das vendas: ");
    scanf("%f",&totalVendas);

    printf("\n Digite o salario fixo: ");
    scanf("%f", &salarioFixo);

    printf("\n Digite a comissao por carro vendido: ");
    scanf("%f",&valorPorCarro);


    salarioFinal = (numCarros * valorPorCarro)+(totalVendas * comissaoFixa)+ salarioFixo;
    
    
    printf("\n Salario Final: %f",salarioFinal);






    
    
    
    
    
    
    }