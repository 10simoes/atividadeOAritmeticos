#include<stdio.h>

main(){

    int numero,dobro;

    printf("Digite um numero qualquer: ");
    scanf("%d",&numero);

    dobro = numero*2;

    printf("\n O dobro do valor digitado é: %d",dobro);
}