#include<stdio.h>

main(){

    float comprimento, largura, area;

    printf("\n Digite o comprimento da sala: ");
    scanf("%f",&comprimento);

    printf("\n Digite a largura da sala: ");
    scanf("%f",&largura);

    area = largura*comprimento;
    
    printf("\n A area da sala é: %.2fm2",area);
}