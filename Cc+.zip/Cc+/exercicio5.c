#include<stdio.h>

main(){

    float custo, valorFrete, despesas, valorVenda, valorBruto, lucro, porcentagemLucro;

    printf("\n Insira o valor de custo da mercadoria: ");
    scanf("%f",&custo);

    printf("\n Insira o valor do frete da mercadoria: ");
    scanf("%f",&valorFrete);

    printf("\n Insira o valor das despesas: ");
    scanf("%f",&despesas);

    printf("\n Insira o valor de venda: ");
    scanf("%f",&valorVenda);

    valorBruto = custo + valorFrete + despesas;

    lucro = (valorVenda - valorBruto)*100;

    porcentagemLucro = (lucro/valorBruto)*100;

    printf("\n A porcentagem do lucro é: %.2f%%",lucro);


}