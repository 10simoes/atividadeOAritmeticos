#include<stdio.h>

main(){

    float anos, meses, dias,idadeEmDias;

    printf("\nDigite a idade em anos: ");
    scanf("%f",&anos);

    printf("\n Digite a idade em meses: ");
    scanf("%f",&meses);

    printf("\n Digite a idade em dias: ");
    scanf("%f",&dias);

    idadeEmDias = anos * 365 + meses * 30 + dias;

    printf("\n A idade e equivalante a %f dias",idadeEmDias);
}
