#include<stdio.h>

main(){

    float salario, percentualReajuste,  reajuste, novoSalario;

    printf("\n Digite o salario: ");
    scanf("f",&salario);

    printf("Digite o percentual de reajuste: ");
    scanf("%f",&percentualReajuste);


    reajuste = salario*(percentualReajuste/100);
    novoSalario = salario + reajuste;

    printf("\n O novo salario é: .2f",novoSalario);


}