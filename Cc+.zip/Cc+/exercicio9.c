#include<stdio.h>

main(){

    float custoFabrica, custoFinal, impostos = 0.45, distribuidor = 0.28;

    printf("\nDigite o custo de fabrica do carro: ");
    scanf("%f",&custoFabrica);

    custoFinal = (custoFabrica * distribuidor) + (custoFabrica * impostos) + custoFabrica;

    printf("O custo final do é: R$%f", custoFinal);
}